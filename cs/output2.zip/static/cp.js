404 Not Found 
 filepath:/home/jindw/workspace/node_modules/cs/static/cp.js
compile failed